from pathlib import Path
import random

from visualmd.base45 import b45encode, b45decode
from visualmd.format import make_blocks, parse_block, reconstruct, serialize_block
from visualmd.gf256 import recover_data


def test_base45_roundtrip():
    for n in range(0, 100):
        data = bytes((i * 37 + n) % 256 for i in range(n))
        assert b45decode(b45encode(data)) == data


def test_block_roundtrip_and_crc():
    raw = (b"# hello\n\n```cpp\nint main(){return 0;}\n```\n" * 200)
    blocks = make_blocks(raw, "notes.md", chunk_size=256, parity_count=3)
    parsed = [parse_block(serialize_block(b)) for b in blocks]
    recovered, ref = reconstruct(parsed)
    assert recovered == raw


def test_erasure_recovery_any_three_missing():
    raw = bytes((i * 17 + i // 7) % 256 for i in range(5000))
    blocks = make_blocks(raw, "blob.py", chunk_size=300, parity_count=3)
    # Remove three data blocks, forcing use of all parity blocks.
    missing = {0, 2, 5}
    kept = [b for b in blocks if b.index not in missing]
    recovered, _ = reconstruct(kept)
    assert recovered == raw


def test_crc_rejects_corruption():
    raw = b"print('hello')\n" * 100
    block = make_blocks(raw, "x.py", chunk_size=200, parity_count=1)[0]
    text = serialize_block(block)
    # Mutate a payload character to another valid Base45 character.
    head, payload = text.rsplit(":", 1)
    replacement = "1" if payload[-1] != "1" else "2"
    bad = head + ":" + payload[:-1] + replacement
    try:
        parse_block(bad)
    except ValueError:
        pass
    else:
        raise AssertionError("corruption should fail CRC")


def test_cauchy_code_recovers_from_every_allowed_erasure_pattern():
    from itertools import combinations
    from visualmd.gf256 import make_parity, recover_data

    data = [bytes(((row * 41 + i * 17) & 0xFF) for i in range(97)) for row in range(5)]
    parity = make_parity(data, 3)
    all_blocks = data + parity
    # Any k=5 of n=8 must recover the original five blocks: all C(8,5)=56 cases.
    for keep in combinations(range(8), 5):
        available = {i: all_blocks[i] for i in keep}
        assert recover_data(available, 5, 3) == data


def test_filename_is_preserved():
    raw = b"# exact filename test\n"
    blocks = make_blocks(raw, "driver_notes.cpp", chunk_size=128, parity_count=1)
    parsed = parse_block(serialize_block(blocks[0]))
    assert parsed.filename == "driver_notes.cpp"
