# VisualMD example

This file demonstrates the intended use case: Markdown mixed with source code.

```cpp
#include <cstdint>

std::uint32_t fold(std::uint32_t value) {
    value ^= value >> 16;
    value *= 0x7feb352dU;
    value ^= value >> 15;
    return value;
}
```

```python
def verify(expected: str, actual: str) -> bool:
    return expected.casefold() == actual.casefold()
```
