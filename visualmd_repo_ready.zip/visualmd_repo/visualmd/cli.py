from __future__ import annotations

import argparse
from pathlib import Path
import sys

from .format import make_blocks
from .sheet import render_sheets


def _encode(args: argparse.Namespace) -> int:
    src = Path(args.input)
    data = src.read_bytes()
    blocks = make_blocks(data, src.name, chunk_size=args.chunk_size, parity_count=args.recovery)
    result = render_sheets(
        blocks,
        src.name,
        args.output,
        columns=args.columns,
        rows=args.rows,
        box_size=args.box_size,
    )
    ref = blocks[0]
    print(f"VisualMD file id: {ref.file_id}")
    print(f"Input: {len(data)} bytes; compressed: {ref.compressed_size} bytes")
    print(f"Blocks: {ref.data_count} data + {ref.parity_count} recovery = {ref.total_count}")
    print(f"Can lose any {ref.parity_count} complete blocks and still recover (assuming remaining blocks decode correctly).")
    for path in result.paths:
        print(f"Wrote: {path}")
    if len(result.paths) > 1:
        print("NOTE: output spans multiple sheets; all sheets are needed unless enough recovery blocks compensate.")
    return 0


def _inspect(args: argparse.Namespace) -> int:
    try:
        from .decode import decode_image
    except ModuleNotFoundError as exc:
        print('Decoder dependencies are missing. Install with: pip install -e ".[decode]"', file=sys.stderr)
        print(f'Missing module: {exc.name}', file=sys.stderr)
        return 2
    report = decode_image(args.image)
    if not report.blocks:
        print("No valid VisualMD blocks decoded.")
        return 2
    by_id: dict[str, list] = {}
    for b in report.blocks:
        by_id.setdefault(b.file_id, []).append(b)
    for file_id, blocks in by_id.items():
        ref = blocks[0]
        indexes = sorted(b.index + 1 for b in blocks)
        print(f"{file_id}: decoded {len(blocks)}/{ref.total_count} blocks; need {ref.data_count}; indexes {indexes}")
    for err in report.rejected:
        print(f"Rejected: {err}", file=sys.stderr)
    return 0


def _decode(args: argparse.Namespace) -> int:
    try:
        from .decode import decode_image, reconstruct_from_images
    except ModuleNotFoundError as exc:
        print('Decoder dependencies are missing. Install with: pip install -e ".[decode]"', file=sys.stderr)
        print(f'Missing module: {exc.name}', file=sys.stderr)
        return 2
    try:
        raw, ref, report = reconstruct_from_images(args.images)
    except ValueError as exc:
        # Still print useful block diagnostics.
        merged = []
        for image in args.images:
            r = decode_image(image)
            merged.extend(r.blocks)
        if merged:
            ref = merged[0]
            indexes = sorted(set(b.index + 1 for b in merged if b.file_id == ref.file_id))
            print(f"Decoded blocks {indexes}; need any {ref.data_count} of {ref.total_count}.", file=sys.stderr)
        print(f"Decode failed: {exc}", file=sys.stderr)
        return 2

    safe_name = Path(ref.filename).name if ref.filename else f"{ref.file_id}.{ref.suffix.lower()}"
    output = Path(args.output) if args.output else Path(f"recovered_{safe_name}")
    output.write_bytes(raw)
    got = sorted(b.index + 1 for b in report.blocks if b.file_id == ref.file_id)
    print(f"Recovered {len(raw)} bytes from blocks {got}")
    print(f"SHA-256 verified: {ref.sha256}")
    print(f"Wrote: {output}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="visualmd", description="Camera-friendly visual transport for source/text files")
    sub = parser.add_subparsers(dest="command", required=True)

    enc = sub.add_parser("encode", help="encode a file into QR sheet(s)")
    enc.add_argument("input")
    enc.add_argument("-o", "--output", default="visualmd.png")
    enc.add_argument("--chunk-size", type=int, default=1800, help="raw bytes protected by each QR (default: 1800)")
    enc.add_argument("--recovery", type=int, default=None, help="whole-block recovery QR count (default: ~25%%)")
    enc.add_argument("--columns", type=int, default=4)
    enc.add_argument("--rows", type=int, default=4)
    enc.add_argument("--box-size", type=int, default=4, help="pixels per QR module in rendered PNG")
    enc.set_defaults(func=_encode)

    dec = sub.add_parser("decode", help="recover a file from one or more photographed sheets")
    dec.add_argument("images", nargs="+")
    dec.add_argument("-o", "--output")
    dec.set_defaults(func=_decode)

    ins = sub.add_parser("inspect", help="show which blocks can be read from a photo")
    ins.add_argument("image")
    ins.set_defaults(func=_inspect)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
