from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import cv2
import numpy as np
from PIL import Image

try:
    from pyzbar.pyzbar import decode as zbar_decode
except Exception:  # pragma: no cover - optional runtime fallback
    zbar_decode = None

from .format import Block, parse_block, reconstruct


@dataclass
class DecodeReport:
    blocks: list[Block]
    rejected: list[str]
    attempts: int
    engines: list[str]


def _decode_zbar(image: np.ndarray) -> list[str]:
    if zbar_decode is None:
        return []
    texts: list[str] = []
    pil = Image.fromarray(image)
    for symbol in zbar_decode(pil):
        try:
            texts.append(symbol.data.decode("ascii"))
        except UnicodeDecodeError:
            continue
    return texts


def _decode_opencv(image: np.ndarray) -> list[str]:
    detector = cv2.QRCodeDetector()
    texts: list[str] = []
    try:
        ok, decoded_info, _points, _ = detector.detectAndDecodeMulti(image)
        if ok and decoded_info:
            texts.extend(t for t in decoded_info if t)
    except cv2.error:
        pass
    try:
        text, _points, _ = detector.detectAndDecode(image)
        if text:
            texts.append(text)
    except cv2.error:
        pass
    return texts


def decode_image(path: str | Path) -> DecodeReport:
    src = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if src is None:
        raise ValueError(f"could not read image: {path}")

    # ZBar is substantially better than OpenCV on high-version QR codes. Try the
    # original photo first; only add image variants if we do not already have
    # enough valid blocks after parsing.
    variants: list[tuple[str, np.ndarray]] = [("original", src)]
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    variants.extend([
        ("clahe", clahe.apply(src)),
        ("otsu", cv2.threshold(src, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]),
    ])

    texts: set[str] = set()
    attempts = 0
    engines: list[str] = []

    for name, variant in variants:
        if zbar_decode is not None:
            attempts += 1
            got = _decode_zbar(variant)
            if got:
                engines.append(f"zbar/{name}")
                texts.update(got)
        # OpenCV adds value mostly on lower-version/cropped codes. Run it only
        # on the original and contrast-normalized image to avoid excessive cost.
        if name != "otsu":
            attempts += 1
            got = _decode_opencv(variant)
            if got:
                engines.append(f"opencv/{name}")
                texts.update(got)

    blocks: dict[tuple[str, int], Block] = {}
    rejected: list[str] = []
    for text in texts:
        if not text.startswith("VMD1:"):
            continue
        try:
            block = parse_block(text)
            blocks[(block.file_id, block.index)] = block
        except Exception as exc:
            rejected.append(str(exc))
    return DecodeReport(blocks=list(blocks.values()), rejected=rejected, attempts=attempts, engines=engines)


def reconstruct_from_images(paths: Iterable[str | Path]) -> tuple[bytes, Block, DecodeReport]:
    merged: dict[tuple[str, int], Block] = {}
    rejected: list[str] = []
    attempts = 0
    engines: list[str] = []
    for path in paths:
        report = decode_image(path)
        attempts += report.attempts
        rejected.extend(report.rejected)
        engines.extend(report.engines)
        for block in report.blocks:
            merged[(block.file_id, block.index)] = block
    final_report = DecodeReport(list(merged.values()), rejected, attempts, engines)
    raw, ref = reconstruct(final_report.blocks)
    return raw, ref, final_report
