"""Minimal RFC 9285 Base45 codec.

Base45's alphabet is QR alphanumeric-friendly, so qrcode libraries can encode the
payload more densely than Base64 in byte mode.
"""

ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:"
_REV = {c: i for i, c in enumerate(ALPHABET)}


def b45encode(data: bytes) -> str:
    out: list[str] = []
    i = 0
    while i + 1 < len(data):
        x = data[i] * 256 + data[i + 1]
        e = x // (45 * 45)
        x %= 45 * 45
        d = x // 45
        c = x % 45
        out.extend((ALPHABET[c], ALPHABET[d], ALPHABET[e]))
        i += 2
    if i < len(data):
        x = data[i]
        d = x // 45
        c = x % 45
        out.extend((ALPHABET[c], ALPHABET[d]))
    return "".join(out)


def b45decode(text: str) -> bytes:
    if len(text) % 3 == 1:
        raise ValueError("invalid Base45 length")
    out = bytearray()
    i = 0
    while i + 2 < len(text):
        try:
            c, d, e = (_REV[text[i]], _REV[text[i + 1]], _REV[text[i + 2]])
        except KeyError as exc:
            raise ValueError(f"invalid Base45 character: {exc.args[0]!r}") from None
        x = c + d * 45 + e * 45 * 45
        if x > 0xFFFF:
            raise ValueError("invalid Base45 triplet")
        out.extend(divmod(x, 256))
        i += 3
    if i < len(text):
        try:
            c, d = _REV[text[i]], _REV[text[i + 1]]
        except KeyError as exc:
            raise ValueError(f"invalid Base45 character: {exc.args[0]!r}") from None
        x = c + d * 45
        if x > 0xFF:
            raise ValueError("invalid Base45 pair")
        out.append(x)
    return bytes(out)
