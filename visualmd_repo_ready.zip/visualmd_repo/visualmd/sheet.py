from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import math

from PIL import Image, ImageDraw, ImageFont
import qrcode
import qrcode.base
from qrcode.constants import ERROR_CORRECT_M
from qrcode.exceptions import DataOverflowError

from .format import Block, serialize_block

# qrcode 8.2 can recurse into the all-zero Reed-Solomon remainder and then
# call glog(0). Representing the zero polynomial explicitly is mathematically
# correct and avoids a rare payload-dependent crash in dense QR codes.
_QR_ORIG_POLY_MOD = qrcode.base.Polynomial.__mod__
def _safe_qr_poly_mod(self, other):
    if not any(self.num):
        return qrcode.base.Polynomial([0], 0)
    return _QR_ORIG_POLY_MOD(self, other)
qrcode.base.Polynomial.__mod__ = _safe_qr_poly_mod



@dataclass(frozen=True)
class SheetResult:
    paths: list[Path]
    blocks_per_page: int
    total_blocks: int


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def qr_image(text: str, *, box_size: int = 4, border: int = 4) -> Image.Image:
    qr = qrcode.QRCode(
        version=None,
        error_correction=ERROR_CORRECT_M,
        box_size=box_size,
        border=border,
    )
    qr.add_data(text, optimize=0)
    try:
        qr.make(fit=True)
    except DataOverflowError as exc:
        raise ValueError(
            "block payload is too large for QR version 40 at ECC M; reduce --chunk-size"
        ) from exc
    return qr.make_image(fill_color="black", back_color="white").convert("L")


def _marker(draw: ImageDraw.ImageDraw, x: int, y: int, s: int) -> None:
    # Simple high-contrast registration target, deliberately not QR-like.
    draw.rectangle((x, y, x+s, y+s), fill="black")
    inset = max(5, s // 4)
    draw.rectangle((x+inset, y+inset, x+s-inset, y+s-inset), fill="white")
    inset2 = max(3, s // 3)
    draw.rectangle((x+inset2, y+inset2, x+s-inset2, y+s-inset2), fill="black")


def render_sheets(
    blocks: list[Block],
    filename: str,
    output: str | Path,
    *,
    columns: int = 4,
    rows: int = 4,
    box_size: int = 4,
) -> SheetResult:
    if not blocks:
        raise ValueError("no blocks to render")
    if columns < 1 or rows < 1:
        raise ValueError("rows and columns must be positive")

    out = Path(output)
    per_page = columns * rows
    pages = math.ceil(len(blocks) / per_page)

    # Pre-render all QRs so every page can size itself consistently.
    qr_images = [qr_image(serialize_block(b), box_size=box_size) for b in blocks]
    qr_side = max(img.width for img in qr_images)

    pad = 52
    gap_x = 28
    gap_y = 64
    top = 250
    label_h = 38
    checksum_line_h = 34
    bottom = 250 + math.ceil(per_page / columns) * checksum_line_h
    cell_w = qr_side
    cell_h = qr_side + label_h
    page_w = pad * 2 + columns * cell_w + (columns - 1) * gap_x
    page_h = top + rows * cell_h + (rows - 1) * gap_y + bottom

    title_font = _font(46, True)
    meta_font = _font(25)
    label_font = _font(23, True)
    small_font = _font(20)
    mono_font = _font(19)

    paths: list[Path] = []
    for p in range(pages):
        page_blocks = blocks[p * per_page:(p + 1) * per_page]
        page_qrs = qr_images[p * per_page:(p + 1) * per_page]
        img = Image.new("L", (page_w, page_h), 255)
        draw = ImageDraw.Draw(img)

        # Registration markers.
        ms = 54
        _marker(draw, 20, 20, ms)
        _marker(draw, page_w - 20 - ms, 20, ms)
        _marker(draw, 20, page_h - 20 - ms, ms)
        _marker(draw, page_w - 20 - ms, page_h - 20 - ms, ms)

        draw.text((pad + 30, 22), "VISUALMD v1", fill=0, font=title_font)
        draw.text((pad + 30, 84), filename, fill=0, font=meta_font)
        ref = blocks[0]
        recovery = ref.parity_count
        meta = (
            f"page {p+1}/{pages}  |  {ref.data_count} data + {recovery} recovery blocks  |  "
            f"zlib  |  {ref.original_size} B -> {ref.compressed_size} B"
        )
        draw.text((pad + 30, 124), meta, fill=0, font=small_font)
        draw.text((pad + 30, 158), f"FILE SHA-256  {ref.sha256}", fill=0, font=mono_font)
        draw.text((pad + 30, 192), "Photograph the whole sheet square-on. Missing blocks can be recovered from parity.", fill=0, font=small_font)

        for n, (block, qr) in enumerate(zip(page_blocks, page_qrs)):
            r = n // columns
            c = n % columns
            x = pad + c * (cell_w + gap_x)
            y = top + r * (cell_h + gap_y)
            # Center smaller QR if versions differ.
            qx = x + (cell_w - qr.width) // 2
            img.paste(qr, (qx, y))
            kind = "REC" if block.is_parity else "DATA"
            label = f"{block.index+1:02d}/{block.total_count:02d}  {kind}  CRC {block.crc32}"
            bbox = draw.textbbox((0, 0), label, font=label_font)
            tw = bbox[2] - bbox[0]
            draw.text((x + (cell_w - tw)//2, y + qr_side + 5), label, fill=0, font=label_font)

        # Human-readable checksum table. This is redundant with the machine block header.
        cy = top + rows * cell_h + (rows - 1) * gap_y + 36
        draw.text((pad, cy), "BLOCK CHECKSUMS (CRC32)", fill=0, font=label_font)
        cy += 38
        for rr in range(math.ceil(len(page_blocks) / columns)):
            for c in range(columns):
                n = rr * columns + c
                if n >= len(page_blocks):
                    break
                b = page_blocks[n]
                text = f"{b.index+1:02d}  {b.crc32}"
                x = pad + c * (cell_w + gap_x)
                draw.text((x, cy + rr * checksum_line_h), text, fill=0, font=mono_font)

        # Output naming.
        if pages == 1:
            path = out
        else:
            path = out.with_name(f"{out.stem}_page_{p+1:02d}{out.suffix or '.png'}")
        path.parent.mkdir(parents=True, exist_ok=True)
        img.save(path, format="PNG", optimize=True)
        paths.append(path)

    return SheetResult(paths=paths, blocks_per_page=per_page, total_blocks=len(blocks))
