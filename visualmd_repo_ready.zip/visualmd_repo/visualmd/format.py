from __future__ import annotations

from dataclasses import dataclass
import base64
import hashlib
import math
import os
import zlib

from .base45 import b45decode, b45encode
from .gf256 import make_parity, recover_data

MAGIC = "VMD1"


@dataclass(frozen=True)
class Block:
    file_id: str
    index: int
    data_count: int
    parity_count: int
    chunk_size: int
    compressed_size: int
    original_size: int
    sha256: str
    suffix: str
    filename: str
    crc32: str
    payload: bytes

    @property
    def total_count(self) -> int:
        return self.data_count + self.parity_count

    @property
    def is_parity(self) -> bool:
        return self.index >= self.data_count


def _safe_suffix(filename: str) -> str:
    ext = os.path.splitext(filename)[1].lower().lstrip(".")
    if 0 < len(ext) <= 8 and ext.isalnum():
        return ext
    return "txt"


def make_blocks(data: bytes, filename: str, *, chunk_size: int = 1600, parity_count: int | None = None) -> list[Block]:
    if chunk_size < 128:
        raise ValueError("chunk_size must be at least 128")
    compressed = zlib.compress(data, level=9)
    data_count = max(1, math.ceil(len(compressed) / chunk_size))
    if parity_count is None:
        # ~25% whole-block erasure tolerance, minimum 2 for non-trivial files.
        parity_count = 1 if data_count == 1 else max(2, math.ceil(data_count * 0.25))
    if parity_count < 0:
        raise ValueError("parity_count must be non-negative")
    if data_count + parity_count > 256:
        raise ValueError("too many blocks; increase chunk_size")

    padded = compressed + bytes(data_count * chunk_size - len(compressed))
    data_blocks = [padded[i * chunk_size:(i + 1) * chunk_size] for i in range(data_count)]
    parity_blocks = make_parity(data_blocks, parity_count) if parity_count else []
    all_payloads = data_blocks + parity_blocks

    sha = hashlib.sha256(data).hexdigest().upper()
    file_id = sha[:12]
    suffix = _safe_suffix(filename).upper()
    stored_name = os.path.basename(filename) or f"file.{suffix.lower()}"
    blocks = []
    for i, payload in enumerate(all_payloads):
        crc = f"{zlib.crc32(payload) & 0xFFFFFFFF:08X}"
        blocks.append(Block(
            file_id=file_id,
            index=i,
            data_count=data_count,
            parity_count=parity_count,
            chunk_size=chunk_size,
            compressed_size=len(compressed),
            original_size=len(data),
            sha256=sha,
            suffix=suffix,
            filename=stored_name,
            crc32=crc,
            payload=payload,
        ))
    return blocks


def serialize_block(block: Block) -> str:
    # Entire header is QR-alphanumeric compatible. No lowercase, underscore, etc.
    # Fields are fixed-order and separated by ':' (part of QR alphanumeric alphabet).
    header = ":".join([
        MAGIC,
        block.file_id,
        str(block.index),
        str(block.data_count),
        str(block.parity_count),
        str(block.chunk_size),
        str(block.compressed_size),
        str(block.original_size),
        block.sha256,
        block.suffix,
        base64.b32encode(block.filename.encode("utf-8")).decode("ascii").rstrip("="),
        block.crc32,
    ])
    return header + ":" + b45encode(block.payload)


def parse_block(text: str) -> Block:
    parts = text.strip().split(":", 12)
    if len(parts) != 13 or parts[0] != MAGIC:
        raise ValueError("not a VisualMD v1 block")
    _, file_id, idx, k, r, chunk, clen, olen, sha, suffix, name32, crc, encoded = parts
    pad = "=" * ((8 - len(name32) % 8) % 8)
    filename = base64.b32decode(name32 + pad).decode("utf-8")
    payload = b45decode(encoded)
    block = Block(
        file_id=file_id,
        index=int(idx),
        data_count=int(k),
        parity_count=int(r),
        chunk_size=int(chunk),
        compressed_size=int(clen),
        original_size=int(olen),
        sha256=sha,
        suffix=suffix,
        filename=filename,
        crc32=crc,
        payload=payload,
    )
    validate_block(block)
    return block


def validate_block(block: Block) -> None:
    if len(block.payload) != block.chunk_size:
        raise ValueError(f"block {block.index}: wrong payload size")
    actual_crc = f"{zlib.crc32(block.payload) & 0xFFFFFFFF:08X}"
    if actual_crc != block.crc32:
        raise ValueError(f"block {block.index}: CRC mismatch {actual_crc} != {block.crc32}")
    if block.index < 0 or block.index >= block.total_count:
        raise ValueError("block index outside declared range")
    if len(block.sha256) != 64:
        raise ValueError("invalid SHA-256 field")
    if block.file_id != block.sha256[:12]:
        raise ValueError("file id does not match SHA-256 prefix")


def reconstruct(blocks: list[Block]) -> tuple[bytes, Block]:
    if not blocks:
        raise ValueError("no VisualMD blocks supplied")
    ref = blocks[0]
    invariant = (
        ref.file_id, ref.data_count, ref.parity_count, ref.chunk_size,
        ref.compressed_size, ref.original_size, ref.sha256, ref.suffix, ref.filename,
    )
    valid: dict[int, bytes] = {}
    for block in blocks:
        validate_block(block)
        candidate = (
            block.file_id, block.data_count, block.parity_count, block.chunk_size,
            block.compressed_size, block.original_size, block.sha256, block.suffix, block.filename,
        )
        if candidate != invariant:
            raise ValueError("blocks belong to different files or incompatible encodings")
        valid.setdefault(block.index, block.payload)

    if len(valid) < ref.data_count:
        missing = ref.data_count - len(valid)
        raise ValueError(
            f"insufficient blocks: have {len(valid)} valid unique blocks, "
            f"need {ref.data_count} ({missing} more)"
        )

    if all(i in valid for i in range(ref.data_count)):
        data_blocks = [valid[i] for i in range(ref.data_count)]
    else:
        data_blocks = recover_data(valid, ref.data_count, ref.parity_count)

    compressed = b"".join(data_blocks)[:ref.compressed_size]
    try:
        raw = zlib.decompress(compressed)
    except zlib.error as exc:
        raise ValueError(f"decompression failed: {exc}") from exc
    if len(raw) != ref.original_size:
        raise ValueError(f"recovered size mismatch: {len(raw)} != {ref.original_size}")
    sha = hashlib.sha256(raw).hexdigest().upper()
    if sha != ref.sha256:
        raise ValueError(f"whole-file SHA-256 mismatch: {sha} != {ref.sha256}")
    return raw, ref
