"""Tiny GF(256) erasure codec used for whole-QR recovery blocks.

This is not QR's internal ECC. It protects against entire QR blocks being
missing/unreadable. The systematic generator is [I; C], where C is a Cauchy
matrix, making any k rows invertible (for k+r <= 256).
"""

POLY = 0x11D
_EXP = [0] * 512
_LOG = [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i] = _x
    _LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= POLY
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]


def mul(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    return _EXP[_LOG[a] + _LOG[b]]


def inv(a: int) -> int:
    if a == 0:
        raise ZeroDivisionError("GF(256) inverse of zero")
    return _EXP[255 - _LOG[a]]


def _cauchy_coeff(parity_row: int, col: int, parity_count: int) -> int:
    # x values occupy [0, r), y values [r, r+k), so x XOR y is non-zero.
    return inv(parity_row ^ (parity_count + col))


def generator_row(index: int, data_count: int, parity_count: int) -> list[int]:
    if index < 0 or index >= data_count + parity_count:
        raise IndexError(index)
    if data_count + parity_count > 256:
        raise ValueError("at most 256 total blocks are supported")
    if index < data_count:
        row = [0] * data_count
        row[index] = 1
        return row
    p = index - data_count
    return [_cauchy_coeff(p, c, parity_count) for c in range(data_count)]


def _mul_table(coef: int) -> bytes:
    return bytes(mul(coef, x) for x in range(256))


def make_parity(data_blocks: list[bytes], parity_count: int) -> list[bytes]:
    if not data_blocks:
        raise ValueError("no data blocks")
    width = len(data_blocks[0])
    if any(len(b) != width for b in data_blocks):
        raise ValueError("all data blocks must have equal length")
    k = len(data_blocks)
    if k + parity_count > 256:
        raise ValueError("at most 256 total blocks are supported")

    result: list[bytes] = []
    for p in range(parity_count):
        acc = bytearray(width)
        for col, block in enumerate(data_blocks):
            coef = _cauchy_coeff(p, col, parity_count)
            table = _mul_table(coef)
            for i, value in enumerate(block):
                acc[i] ^= table[value]
        result.append(bytes(acc))
    return result


def invert_matrix(matrix: list[list[int]]) -> list[list[int]]:
    n = len(matrix)
    if n == 0 or any(len(row) != n for row in matrix):
        raise ValueError("matrix must be non-empty and square")
    aug = [row[:] + [1 if i == j else 0 for j in range(n)] for i, row in enumerate(matrix)]

    for col in range(n):
        pivot = next((r for r in range(col, n) if aug[r][col]), None)
        if pivot is None:
            raise ValueError("singular GF(256) matrix")
        if pivot != col:
            aug[col], aug[pivot] = aug[pivot], aug[col]

        scale = inv(aug[col][col])
        if scale != 1:
            table = _mul_table(scale)
            aug[col] = [table[v] for v in aug[col]]

        for r in range(n):
            if r == col:
                continue
            factor = aug[r][col]
            if factor:
                table = _mul_table(factor)
                aug[r] = [a ^ table[b] for a, b in zip(aug[r], aug[col])]

    return [row[n:] for row in aug]


def recover_data(available: dict[int, bytes], data_count: int, parity_count: int) -> list[bytes]:
    """Recover the original k data blocks from any k valid blocks."""
    if len(available) < data_count:
        raise ValueError(f"need {data_count} blocks, only {len(available)} available")
    selected = sorted(available)[:data_count]
    blocks = [available[i] for i in selected]
    width = len(blocks[0])
    if any(len(b) != width for b in blocks):
        raise ValueError("available blocks have inconsistent sizes")

    matrix = [generator_row(i, data_count, parity_count) for i in selected]
    inverse = invert_matrix(matrix)
    recovered: list[bytes] = []
    for row in inverse:
        acc = bytearray(width)
        for coef, block in zip(row, blocks):
            if coef == 0:
                continue
            if coef == 1:
                for i, value in enumerate(block):
                    acc[i] ^= value
            else:
                table = _mul_table(coef)
                for i, value in enumerate(block):
                    acc[i] ^= table[value]
        recovered.append(bytes(acc))
    return recovered
